# Slice B — how to apply this to your repo

This zip contains only the files that are new or changed for Slice B
(today's beat, visit check-in/close, off-beat search, new-outlet OTP flow).
Everything else in your repo is untouched.

## In your GitHub Codespace terminal

1. Open your Codespace on `gauravalung/flowmint-sfa` (same one you used for
   the earlier fixes — `github.com/gauravalung/flowmint-sfa` → Code →
   Codespaces).
2. Drag-and-drop `slice-b-changes.zip` into the Codespace's file explorer
   (the left sidebar) to upload it into the workspace root, or use the
   "Upload..." option from the explorer's `...` menu.
3. In the terminal:

```
cd /workspaces/flowmint-sfa
unzip -o slice-b-changes.zip -d /tmp/slice-b
rm -rf /tmp/slice-b/APPLY_INSTRUCTIONS.md
cp -r /tmp/slice-b/apps /tmp/slice-b/packages .
rm -f apps/mobile/src/screens/HomeScreen.tsx
```

That copies every new/changed file into place and removes the old
placeholder Home screen (replaced by Today's Beat).

4. Rebuild the shared package and sanity-check both sides compile:

```
npm install
npm run build:shared
npm --workspace=apps/api run build
cd apps/mobile && npx tsc --noEmit && cd ../..
```

5. Commit and push:

```
git add -A
git commit -m "Slice B: today's beat, visit check-in/close, off-beat search, new outlet OTP flow"
git push
```

6. Render will redeploy `flowmint-api` automatically on push (it's watching
   `main`). Give it a few minutes, then confirm it's live the same way we
   checked before:

```
curl -sS -X POST https://flowmint-api.onrender.com/api/v1/me/beat/today
```

   (should return `{"error":{"code":"AUTH_REQUIRED",...}}` — that's correct,
   it means the route exists and is protected.)

7. Because mobile code changed, the APK on your friend's phone is now
   out of date — it doesn't have these new screens. Build a fresh one:

```
cd apps/mobile
export EXPO_TOKEN=your_token_here
npx eas-cli build -p android --profile preview
```

   Once it finishes, reinstall the new APK on the phone the same way as
   before.

## What's new in this build

- **Today's Beat** replaces the placeholder home screen — shows the
  salesman's assigned retailers for today in visit sequence, with live
  status (not visited / in progress / no order).
- Tapping a retailer opens **Retailer Detail** — name, owner, address,
  tap-to-call, and a Start Visit button.
- Starting a visit takes you to **Close Visit**, where the only outcome
  available right now is "No Order" with a reason — order booking needs
  the product catalog, which is Slice C, not built yet.
- **Off-beat retailer** search — find and visit any retailer in your
  distributor's book, not just today's assigned list.
- **+ New outlet** — add a shop that isn't in the system yet, OTP-verified
  against the shop's own phone number before it's created.
- Login sessions now survive longer than 15 minutes — a real gap from
  Slice A that would have silently broken the app mid-shift. Fixed as part
  of this slice since it's the first slice where the app is used for more
  than a couple of minutes at a time.
